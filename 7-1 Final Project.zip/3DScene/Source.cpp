#include "ShapeGenerator.h"
#include "ShapeData.h"
#include <glad/glad.h>
#include <GLFW/glfw3.h>     // GLFW library

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      // Image loading Utility functions

#include <math.h>

#include <iostream> 

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"

using namespace std; // Uses the standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

constexpr auto PI = 3.14159265359;

//Standard namespace
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 800;
	const int WINDOW_HEIGHT = 600;

	// Stores the GL data relative to a given mesh
	struct GLMesh
	{
		GLuint vao;         // Handle for the vertex array object
		GLuint vbos[2];     // Handles for the vertex buffer objects
		GLuint nIndices;    // Number of indices of the mesh

		// sphere
		GLuint sphereIndexByteOffset;
	};

	// Main GLFW window
	GLFWwindow* gWindow = nullptr;

	// Light Cube
	GLMesh gLightCubeMesh;

	// Wall
	GLMesh gWallMesh;
	GLMesh gBaseboardMesh;

	// Floor
	GLMesh gFloorMesh;
	GLuint gFloorTexture;

	// Storage Cube
	GLMesh gStorageCubeMesh;
	GLuint gStorageCubeTexture;
	GLuint gStorageCubeExtraTexture;

	// Shaker Meshs
	GLMesh gShaker1BottomMesh;
	GLMesh gShaker1TopMesh;
	GLMesh gShaker2BottomMesh;
	GLMesh gShaker2TopMesh;

	// Shape Sorter Base Mesh
	GLMesh gShapeSorterBaseMesh;
	// Shape Sorter Circle Mesh
	GLMesh gShapeSorterCircleMesh;
	// Shape Sorter Rectangle Mesh
	GLMesh gShapeSorterRectangleMesh;
	// Shape Sorter Triangle Mesh
	GLMesh gShapeSorterTriangleMesh;
	// Shape Sorter Square Mesh
	GLMesh gShapeSorterSquareMesh;
	// Shape Sorter Pentagon Mesh
	GLMesh gShapeSorterPentagonMesh;

	// Stacker Mesh
	GLMesh gStackerBaseMesh;
	GLMesh gStackerCenterMesh;
	GLMesh gStackerRing1Mesh;
	GLMesh gStackerRing2Mesh;
	GLMesh gStackerRing3Mesh;
	GLMesh gStackerRing4Mesh;
	GLMesh gStackerRing5Mesh;

	GLMesh gBallMesh;

	// Solid Color Textures
	GLuint gSorterBaseTexture;
	GLuint gPinkTexture;
	GLuint gYellowTexture;
	GLuint gGreenTexture;
	GLuint gBlueTexture;
	GLuint gOrangeTexture;
	GLuint gWhiteTexture;
	GLuint gLightGrayTexture;
	GLuint gGrayTexture;
	GLuint gBlackTexture;
	GLuint gOffWhiteTexture;

	// Shader program
	GLuint gProgramId;

	// camera
	Camera gCamera(glm::vec3(3.0f, 5.0f, 20.0f));
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	float gDeltaTime = 0.0f; // Time between current frame and last frame
	float gLastFrame = 0.0f;

	// positions of the point lights
	glm::vec3 pointLightPositions[] = {
		glm::vec3(-20.0f,  30.0f,  -10.0f),
		glm::vec3(20.0f,  30.0f,  -10.0f)
	};

	enum CameraView {
		PERSPECTIVE,
		ORTHOGRAPHIC
	};

	bool gCameraKeyDepressed = false;
	CameraView gCameraView = PERSPECTIVE;

	bool gExtraTexture = true;

	// Default scale, rotation, translation
	// Scale
	glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
	// Rotate
	glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	// Translation
	glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
	glm::mat4 model = translation * rotation * scale;

	// offset variables for sphere
	const uint NUM_VERTICES_PER_TRI = 3;
	const uint NUM_FLOATS_PER_VERTICE = 9;
	const uint VERTEX_BYTE_SIZE = NUM_FLOATS_PER_VERTICE * sizeof(float);
}

//Definitions
bool Init(int argc, char* argv[], GLFWwindow** window);
void WindowResize_Callback(GLFWwindow* window, int width, int height);
void MousePosition_Callback(GLFWwindow* window, double xpos, double ypos);
void MouseScroll_Callback(GLFWwindow* window, double xoffset, double yoffset);

void ProcessInput(GLFWwindow* window);

void CreateLightCubeMesh(GLMesh& mesh);

void CreateFloorMesh(GLMesh& mesh);
void CreateWallMesh(GLMesh& mesh);

void CreateCylinderMesh(GLMesh& mesh, float xPos, float zPos, float bottom, float top, float bottomRadius, float topRadius);
void CreateCubeMesh(GLMesh& mesh, float left, float right, float bottom, float top, float front, float back);
void CreateSphereMesh(GLMesh& mesh);

void CreateShapeSorterBaseMesh(GLMesh& mesh, float left, float right, float bottom, float top, float front, float back);
void CreateShapeSorterTriangleMesh(GLMesh& mesh);
void CreateShapeSorterPentagonMesh(GLMesh& mesh);

void DestroyMesh(GLMesh& mesh);

void LoadAllTextures();
bool CreateTexture(const char* filename, GLuint& textureId);
void flipImageVertically(unsigned char* image, int width, int height, int channels);
void DestroyTexture(GLuint textureId);

void Render(Shader lightingShader, Shader lightCubeShader);

int main(int argc, char* argv[])
{
	//Init GLFW and GLEW
	if (!Init(argc, argv, &gWindow))
		return -1;

	// build and compile our shader zprogram
	// ------------------------------------
	Shader lightingShader("shaders/multiLights.vs", "shaders/multiLights.fs");
	Shader lightCubeShader("shaders/lightCube.vs", "shaders/lightCube.fs");

	CreateLightCubeMesh(gLightCubeMesh);

	// Create the floor mesh
	CreateFloorMesh(gFloorMesh);

	// Create the wall mesh
	CreateWallMesh(gWallMesh);
	CreateCubeMesh(gBaseboardMesh, -50.0f, 30.0f, 0.0f, 4.0f, -19.8f, -20.0f);

	// Create the storage cube mesh
	CreateCubeMesh(gStorageCubeMesh, -5.0f, 5.0f, 0.0f, 10.0f, 0.0f, -10.0f);

	// Create the shaker meshs
	CreateCylinderMesh(gShaker1BottomMesh, -4.5f, 3.0f, 0.0f, 3.0f, 1.0f, 0.75f);
	CreateCylinderMesh(gShaker1TopMesh, -4.5f, 3.0f, 3.0f, 4.0f, 0.75f, 1.0f);
	CreateCylinderMesh(gShaker2BottomMesh, -4.5f, 3.0f, 0.0f, 3.0f, 1.0f, 0.75f);
	CreateCylinderMesh(gShaker2TopMesh, -4.5f, 3.0f, 3.0f, 4.0f, 0.75f, 1.0f);

	// Create the shape sorter meshes
	CreateShapeSorterBaseMesh(gShapeSorterBaseMesh, -6.0f, 6.0f, 0.0f, 1.0f, 0.0f, 3.0f);
	CreateCylinderMesh(gShapeSorterCircleMesh, -4.5f, 1.5f, 1.0f, 3.0f, 1.0f, 1.0f);
	CreateCubeMesh(gShapeSorterRectangleMesh, -3.0f, -2.0f, 1.0f, 3.0f, 0.5f, 2.5f);
	CreateCubeMesh(gShapeSorterSquareMesh, 1.0f, 3.0f, 1.0f, 3.0f, 0.5f, 2.5f);
	CreateShapeSorterTriangleMesh(gShapeSorterTriangleMesh);
	CreateShapeSorterPentagonMesh(gShapeSorterPentagonMesh);

	// Create the stacker meshes
	CreateCubeMesh(gStackerBaseMesh, -3.0f, 3.0f, 0.0f, 1.0f, 0.0f, 6.0f);
	CreateCylinderMesh(gStackerCenterMesh, 0.0f, 3.0f, 1.0f, 7.0f, 1.0f, 0.8f);
	CreateCylinderMesh(gStackerRing1Mesh, 0.0f, 3.0f, 1.0f, 2.0f, 2.75f, 2.75f);
	CreateCylinderMesh(gStackerRing2Mesh, 0.0f, 3.0f, 2.0f, 3.0f, 2.5625f, 2.5625f);
	CreateCylinderMesh(gStackerRing3Mesh, 0.0f, 3.0f, 3.0f, 4.0f, 2.375f, 2.375f);
	CreateCylinderMesh(gStackerRing4Mesh, 0.0f, 3.0f, 4.0f, 5.0f, 2.1875f, 2.1875f);
	CreateCylinderMesh(gStackerRing5Mesh, 0.0f, 3.0f, 5.0f, 6.0f, 2.0f, 2.0f);

	// Create the ball mesh
	CreateSphereMesh(gBallMesh);

	// Load all needed textures
	LoadAllTextures();

	// shader configuration
	// --------------------
	lightingShader.use();
	lightingShader.setInt("material.diffuse", 0);
	lightingShader.setInt("material.diffuseExtra", 1);

	// Keep looping until user exits
	while (!glfwWindowShouldClose(gWindow))
	{
		// Handle User Input
		ProcessInput(gWindow);

		// Render this frame
		Render(lightingShader, lightCubeShader);

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(gWindow);
		glfwPollEvents();
	}

	// Release mesh data
	DestroyMesh(gLightCubeMesh);

	DestroyMesh(gFloorMesh);
	DestroyTexture(gFloorTexture);

	DestroyMesh(gWallMesh);
	DestroyMesh(gBaseboardMesh);

	DestroyMesh(gStorageCubeMesh);
	DestroyTexture(gStorageCubeTexture);
	DestroyTexture(gStorageCubeExtraTexture);

	DestroyMesh(gShaker1BottomMesh);
	DestroyMesh(gShaker1TopMesh);
	DestroyMesh(gShaker2BottomMesh);
	DestroyMesh(gShaker2TopMesh);

	DestroyMesh(gShapeSorterBaseMesh);
	DestroyMesh(gShapeSorterCircleMesh);
	DestroyMesh(gShapeSorterRectangleMesh);
	DestroyMesh(gShapeSorterTriangleMesh);
	DestroyMesh(gShapeSorterSquareMesh);
	DestroyMesh(gShapeSorterPentagonMesh);

	DestroyMesh(gStackerBaseMesh);
	DestroyMesh(gStackerCenterMesh);
	DestroyMesh(gStackerRing1Mesh);
	DestroyMesh(gStackerRing2Mesh);
	DestroyMesh(gStackerRing3Mesh);
	DestroyMesh(gStackerRing4Mesh);
	DestroyMesh(gStackerRing5Mesh);

	DestroyMesh(gBallMesh);

	DestroyTexture(gSorterBaseTexture);
	DestroyTexture(gPinkTexture);
	DestroyTexture(gYellowTexture);
	DestroyTexture(gGreenTexture);
	DestroyTexture(gBlueTexture);
	DestroyTexture(gOrangeTexture);
	DestroyTexture(gWhiteTexture);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();

	return 0;
}

//Initializes GLFW and GLEW
bool Init(int argc, char* argv[], GLFWwindow** window)
{
	// GLFW: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// GLFW: window creation
	// ---------------------
	*window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "CS-330 Final Project", NULL, NULL);
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, WindowResize_Callback);
	glfwSetCursorPosCallback(*window, MousePosition_Callback);
	glfwSetScrollCallback(*window, MouseScroll_Callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// Displays GPU OpenGL version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	return true;
}

//Gets calles when the size of the window changes
void WindowResize_Callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void MousePosition_Callback(GLFWwindow* window, double xpos, double ypos)
{
	// First call
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	// Process mouse movement
	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

	// Set last postions
	gLastX = xpos;
	gLastY = ypos;

	// Send data to camera object
	gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void MouseScroll_Callback(GLFWwindow* window, double xoffset, double yoffset)
{
	// Send scroll data to camera object to handle speed
	gCamera.ProcessMouseScroll(yoffset);
}

//Processes the input from the user
void ProcessInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	// Handle Key Inputs
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		gCamera.ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		gCamera.ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		gCamera.ProcessKeyboard(DOWN, gDeltaTime);

	if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
		gCamera.ProcessKeyboard(PAN_LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
		gCamera.ProcessKeyboard(PAN_RIGHT, gDeltaTime);

	if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
		gCamera.ProcessKeyboard(TILT_UP, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
		gCamera.ProcessKeyboard(TILT_DOWN, gDeltaTime);

	// Detect press of "P" key
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		// If key press is new, set flag
		if (!gCameraKeyDepressed)
			gCameraKeyDepressed = true;

	// Detect release of "P" key
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_RELEASE)
		// Only run if key was down
		if (gCameraKeyDepressed)
		{
			// Revert flag to allow another key press
			gCameraKeyDepressed = false;

			// Change camera view
			if (gCameraView == PERSPECTIVE)
				gCameraView = ORTHOGRAPHIC;
			else
				gCameraView = PERSPECTIVE;
		}
}

// Create Light Cube Mesh
void CreateLightCubeMesh(GLMesh& mesh)
{
	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------
	float vertices[] = {
		// positions          // normals           // texture coords
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		-0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

//Create the vertex and indicies for wall mesh
void CreateWallMesh(GLMesh& mesh)
{
	// Position and Color data
	GLfloat verts[] = {
		// Add verts for wall plane
		// Vertex Positions     //Normals				// Texture Coordinates
		// ******************************************************************************
		//Front Face				//Positive Z Normal
		-50.0f, 0.0f,  -20.0f,		0.0f, 0.0f,  1.0f,		0.0f, 0.0f,
		 30.0f, 0.0f,  -20.0f,		0.0f, 0.0f,  1.0f,		1.0f, 0.0f,
		-50.0f, 40.0f, -20.0f,		0.0f, 0.0f,  1.0f,		0.0f, 1.0f,

		-50.0f, 40.0f, -20.0f,		0.0f, 0.0f,  1.0f,		0.0f, 0.0f,
		 30.0f, 40.0f, -20.0f,		0.0f, 0.0f,  1.0f,		1.0f, 0.0f,
		 30.0f, 0.0f,  -20.0f,		0.0f, 0.0f,  1.0f,		0.0f, 1.0f
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

//Create the vertex and indicies for Floor mesh
void CreateFloorMesh(GLMesh& mesh)
{
	// Position and Color data
	GLfloat verts[] = {
		// Add verts for floor plane
		// Vertex Positions     //Normals				// Texture Coordinates
		// ******************************************************************************
		//Top Face				//Positive Y Normal
		-50.0f, 0.0f, -20.0f,   0.0f, 1.0f,  0.0f,		0.0f, 0.0f,
		 30.0f, 0.0f, -20.0f,   0.0f, 1.0f,  0.0f,		1.0f, 0.0f,
		-50.0f, 0.0f,  30.0f,   0.0f, 1.0f,  0.0f,		0.0f, 1.0f,
		 30.0f, 0.0f,  30.0f,   0.0f, 1.0f,  0.0f,		1.0f, 1.0f
	};

	// Index data to share position data
	// Floor = 1 sides * 2 triangles * 3 verts = 6
	// Total = 6
	GLushort indices[6] = {
		// Stacker Base
		0, 1, 2,   // Side 1
		1, 2, 3
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

// Create Cylinder Mesh
void CreateCylinderMesh(GLMesh& mesh, float xPos, float zPos, float bottom, float top, float bottomRadius, float topRadius)
{
	// Position and Color data

	// Base and top of cylinder
	GLfloat x = xPos;
	GLfloat z = zPos;
	GLint numberOfSides = 16;

	// numberOfVertices = numberOfSides + 2
	int numberOfVertices = numberOfSides + 2;

	GLfloat twicePi = 2.0f * PI;

	// Circle verts = numberOfVerticies * 8 data points
	// Total verts = base circle + top circle

	// Set arrays to numberOfVertices
	GLfloat circleVerticesX_Bottom[18];
	GLfloat circleVerticesZ_Bottom[18];
	GLfloat circleVerticesX_Top[18];
	GLfloat circleVerticesZ_Top[18];

	//Bottom Circle = numberOfSides * 3 points * 8 data values
	//Top Circle = numberOfSides * 3 points * 8 data values
	GLfloat verts[1536];

	// Calculate the verticies for bottom
	// First vert is center of circle
	circleVerticesX_Bottom[0] = x;
	circleVerticesZ_Bottom[0] = z;
	for (int i = 1; i < numberOfVertices; i++)
	{
		circleVerticesX_Bottom[i] = x + (bottomRadius * cos(i * twicePi / numberOfSides));
		circleVerticesZ_Bottom[i] = z + (bottomRadius * sin(i * twicePi / numberOfSides));
	}

	// Bottom Circle
	for (int i = 0; i < numberOfSides; i++)
	{
		// Center Point
		verts[0 + (i * 24) + 0] = circleVerticesX_Bottom[0];
		verts[0 + (i * 24) + 1] = bottom;
		verts[0 + (i * 24) + 2] = circleVerticesZ_Bottom[0];

		// Negative Y Normals
		verts[0 + (i * 24) + 3] = 0.0f;
		verts[0 + (i * 24) + 4] = -1.0f;
		verts[0 + (i * 24) + 5] = 0.0f;

		// Texture
		verts[0 + (i * 24) + 6] = 0.0f;
		verts[0 + (i * 24) + 7] = 1.0f;


		// Point 1
		verts[0 + (i * 24) + 8] = circleVerticesX_Bottom[i + 1];
		verts[0 + (i * 24) + 9] = bottom;
		verts[0 + (i * 24) + 10] = circleVerticesZ_Bottom[i + 1];

		// Negative Y Normals
		verts[0 + (i * 24) + 11] = 0.0f;
		verts[0 + (i * 24) + 12] = -1.0f;
		verts[0 + (i * 24) + 13] = 0.0f;

		// Texture
		verts[0 + (i * 24) + 14] = 0.0f;
		verts[0 + (i * 24) + 15] = 1.0f;


		// Point 2
		verts[0 + (i * 24) + 16] = circleVerticesX_Bottom[i + 2];
		verts[0 + (i * 24) + 17] = bottom;
		verts[0 + (i * 24) + 18] = circleVerticesZ_Bottom[i + 2];

		// Negative Y Normals
		verts[0 + (i * 24) + 19] = 0.0f;
		verts[0 + (i * 24) + 20] = -1.0f;
		verts[0 + (i * 24) + 21] = 0.0f;

		// Texture
		verts[0 + (i * 24) + 22] = 0.0f;
		verts[0 + (i * 24) + 23] = 1.0f;
	}

	// Calculate the verticies for top - Allows for radius size change
	// First vert is center of circle
	circleVerticesX_Top[0] = x;
	circleVerticesZ_Top[0] = z;
	for (int i = 1; i < numberOfVertices; i++)
	{
		circleVerticesX_Top[i] = x + (topRadius * cos(i * twicePi / numberOfSides));
		circleVerticesZ_Top[i] = z + (topRadius * sin(i * twicePi / numberOfSides));
	}

	// Top Circle
	int startingVert = (numberOfSides * 3 * 8);
	for (int i = 0; i < numberOfSides; i++)
	{
		// Center Point
		verts[startingVert + (i * 24) + 0] = circleVerticesX_Top[0];
		verts[startingVert + (i * 24) + 1] = top;
		verts[startingVert + (i * 24) + 2] = circleVerticesZ_Top[0];

		// Positive Y Normals
		verts[startingVert + (i * 24) + 3] = 0.0f;
		verts[startingVert + (i * 24) + 4] = 1.0f;
		verts[startingVert + (i * 24) + 5] = 0.0f;

		// Texture
		verts[startingVert + (i * 24) + 6] = 0.0f;
		verts[startingVert + (i * 24) + 7] = 1.0f;


		// Point 1
		verts[startingVert + (i * 24) + 8] = circleVerticesX_Top[i + 1];
		verts[startingVert + (i * 24) + 9] = top;
		verts[startingVert + (i * 24) + 10] = circleVerticesZ_Top[i + 1];

		// Positive Y Normals
		verts[startingVert + (i * 24) + 11] = 0.0f;
		verts[startingVert + (i * 24) + 12] = 1.0f;
		verts[startingVert + (i * 24) + 13] = 0.0f;

		// Texture
		verts[startingVert + (i * 24) + 14] = 0.0f;
		verts[startingVert + (i * 24) + 15] = 1.0f;


		// Point 2
		verts[startingVert + (i * 24) + 16] = circleVerticesX_Top[i + 2];
		verts[startingVert + (i * 24) + 17] = top;
		verts[startingVert + (i * 24) + 18] = circleVerticesZ_Top[i + 2];

		// Positive Y Normals
		verts[startingVert + (i * 24) + 19] = 0.0f;
		verts[startingVert + (i * 24) + 20] = 1.0f;
		verts[startingVert + (i * 24) + 21] = 0.0f;

		// Texture
		verts[startingVert + (i * 24) + 22] = 0.0f;
		verts[startingVert + (i * 24) + 23] = 1.0f;
	}

	// Sides
	startingVert = (numberOfSides * 3 * 8) * 2;
	for (int i = 0; i < (numberOfSides); i++)
	{
#pragma region Triangle 1
		// Bottom Point 1
		verts[startingVert + (i * 48) + 0] = circleVerticesX_Bottom[i + 1];
		verts[startingVert + (i * 48) + 1] = bottom;
		verts[startingVert + (i * 48) + 2] = circleVerticesZ_Bottom[i + 1];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 3] = 0.0f;
		verts[startingVert + (i * 48) + 4] = 0.0f;
		verts[startingVert + (i * 48) + 5] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 6] = 0.0f;
		verts[startingVert + (i * 48) + 7] = 1.0f;


		// Bottom Point 2
		verts[startingVert + (i * 48) + 8] = circleVerticesX_Bottom[i + 2];
		verts[startingVert + (i * 48) + 9] = bottom;
		verts[startingVert + (i * 48) + 10] = circleVerticesZ_Bottom[i + 2];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 11] = 0.0f;
		verts[startingVert + (i * 48) + 12] = 0.0f;
		verts[startingVert + (i * 48) + 13] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 14] = 0.0f;
		verts[startingVert + (i * 48) + 15] = 1.0f;


		// Top Point 1
		verts[startingVert + (i * 48) + 16] = circleVerticesX_Top[i + 1];
		verts[startingVert + (i * 48) + 17] = top;
		verts[startingVert + (i * 48) + 18] = circleVerticesZ_Top[i + 1];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 19] = 0.0f;
		verts[startingVert + (i * 48) + 20] = 0.0f;
		verts[startingVert + (i * 48) + 21] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 22] = 0.0f;
		verts[startingVert + (i * 48) + 23] = 1.0f;
#pragma endregion


#pragma region Triangle 2
		// Top Point 1
		verts[startingVert + (i * 48) + 24] = circleVerticesX_Top[i + 1];
		verts[startingVert + (i * 48) + 25] = top;
		verts[startingVert + (i * 48) + 26] = circleVerticesZ_Top[i + 1];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 27] = 0.0f;
		verts[startingVert + (i * 48) + 28] = 0.0f;
		verts[startingVert + (i * 48) + 29] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 30] = 0.0f;
		verts[startingVert + (i * 48) + 31] = 1.0f;


		// Top Point 2
		verts[startingVert + (i * 48) + 32] = circleVerticesX_Top[i + 2];
		verts[startingVert + (i * 48) + 33] = top;
		verts[startingVert + (i * 48) + 34] = circleVerticesZ_Top[i + 2];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 35] = 0.0f;
		verts[startingVert + (i * 48) + 36] = 0.0f;
		verts[startingVert + (i * 48) + 37] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 38] = 0.0f;
		verts[startingVert + (i * 48) + 39] = 1.0f;


		// Bottom Point 2
		verts[startingVert + (i * 48) + 40] = circleVerticesX_Bottom[i + 2];
		verts[startingVert + (i * 48) + 41] = bottom;
		verts[startingVert + (i * 48) + 42] = circleVerticesZ_Bottom[i + 2];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 43] = 0.0f;
		verts[startingVert + (i * 48) + 44] = 0.0f;
		verts[startingVert + (i * 48) + 45] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 46] = 0.0f;
		verts[startingVert + (i * 48) + 47] = 1.0f;
#pragma endregion
	}


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

// Create Cube Mesh
void CreateCubeMesh(GLMesh& mesh, float left, float right, float bottom, float top, float front, float back)
{
	// Position and Color data
	GLfloat verts[] = {
		// Vertex Positions		//Normals				// Texture Coordinates
		// ******************************************************************************
		//Front Face			//Positive Z Normal		
		left, bottom, front,	0.0f, 0.0f, 1.0f,		0.0f, 0.0f,
		right, bottom, front,	0.0f, 0.0f, 1.0f,		1.0f, 0.0f,
		left, top, front,		0.0f, 0.0f, 1.0f,		0.0f, 1.0f,

		left, top, front,		0.0f, 0.0f, 1.0f,		0.0f, 1.0f,
		right, top, front,		0.0f, 0.0f, 1.0f,		1.0f, 1.0f,
		right, bottom, front,	0.0f, 0.0f, 1.0f,		1.0f, 0.0f,

		//Back Face				//Negative Z Normal
		left, bottom, back,		0.0f, 0.0f, -1.0f,		0.0f, 0.0f,
		right, bottom, back,	0.0f, 0.0f, -1.0f,		1.0f, 0.0f,
		left, top, back,		0.0f, 0.0f, -1.0f,		0.0f, 1.0f,

		left, top, back,		0.0f, 0.0f, -1.0f,		0.0f, 1.0f,
		right, top, back,		0.0f, 0.0f, -1.0f,		1.0f, 1.0f,
		right, bottom, back,	0.0f, 0.0f, -1.0f,		1.0f, 0.0f,

		//Right Face			//Positive X Normal
		right, bottom, front,	1.0f, 0.0f, 0.0f,		0.0f, 0.0f,
		right, bottom, back,	1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
		right, top, front,		1.0f, 0.0f, 0.0f,		0.0f, 1.0f,

		right, bottom, back,	1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
		right, top, back,		1.0f, 0.0f, 0.0f,		1.0f, 1.0f,
		right, top, front,		1.0f, 0.0f, 0.0f,		0.0f, 1.0f,

		//Left Face				//Negative X Normal
		left, bottom, front,	-1.0f, 0.0f, 0.0f,		0.0f, 0.0f,
		left, bottom, back,		-1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
		left, top, front,		-1.0f, 0.0f, 0.0f,		0.0f, 1.0f,

		left, bottom, back,		-1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
		left, top, back,		-1.0f, 0.0f, 0.0f,		1.0f, 1.0f,
		left, top, front,		-1.0f, 0.0f, 0.0f,		0.0f, 1.0f,

		//Top Face				//Positive Y Normal
		left, top, front,		0.0f, 1.0f, 0.0f,		0.0f, 0.0f,
		right, top, front,		0.0f, 1.0f, 0.0f,		1.0f, 0.0f,
		left, top, back,		0.0f, 1.0f, 0.0f,		0.0f, 1.0f,

		left, top, back,		0.0f, 1.0f, 0.0f,		0.0f, 1.0f,
		right, top, back,		0.0f, 1.0f, 0.0f,		1.0f, 1.0f,
		right, top, front,		0.0f, 1.0f, 0.0f,		1.0f, 0.0f,

		//Bottom Face			//Negative Y Normal
		left, bottom, front,	0.0f, -1.0f, 0.0f,		0.0f, 0.0f,
		right, bottom, front,	0.0f, -1.0f, 0.0f,		1.0f, 0.0f,
		left, bottom, back,		0.0f, -1.0f, 0.0f,		0.0f, 1.0f,

		left, bottom, back,		0.0f, -1.0f, 0.0f,		0.0f, 1.0f,
		right, bottom, back,	0.0f, -1.0f, 0.0f,		1.0f, 1.0f,
		right, bottom, front,	0.0f, -1.0f, 0.0f,		1.0f, 0.0f,
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

// Create Shpere Mesh
void CreateSphereMesh(GLMesh& mesh)
{
	// creates sphere object
	ShapeData sphere = ShapeGenerator::makeSphere();

	//unsigned int sphereVBO{}, sphereVAO;
	glGenVertexArrays(1, &mesh.vao);
	glGenBuffers(1, mesh.vbos);
	glBindVertexArray(mesh.vao);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
	glBufferData(GL_ARRAY_BUFFER, sphere.vertexBufferSize() + sphere.indexBufferSize(), 0, GL_STATIC_DRAW);
	GLsizeiptr currentOffset = 0;
	glBufferSubData(GL_ARRAY_BUFFER, currentOffset, sphere.vertexBufferSize(), sphere.vertices);
	currentOffset += sphere.vertexBufferSize();
	mesh.sphereIndexByteOffset = currentOffset;
	glBufferSubData(GL_ARRAY_BUFFER, currentOffset, sphere.indexBufferSize(), sphere.indices);
	mesh.nIndices = sphere.numIndices;
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)(sizeof(float) * 3));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)(sizeof(float) * 6));
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[0]);
}

// Create Shape Sorter Base Mesh
void CreateShapeSorterBaseMesh(GLMesh& mesh, float left, float right, float bottom, float top, float front, float back)
{
	// Position and Color data
	GLfloat verts[] = {
		// Vertex Positions		//Normals				// Texture Coordinates
		// ******************************************************************************
		//Front Face			//Positive Z Normal		
		left, bottom, front,	0.0f, 0.0f, 1.0f,		0.0f, 0.0f,
		right, bottom, front,	0.0f, 0.0f, 1.0f,		1.0f, 0.0f,
		left, top, front,		0.0f, 0.0f, 1.0f,		0.0f, 0.2f,

		left, top, front,		0.0f, 0.0f, 1.0f,		0.0f, 0.2f,
		right, top, front,		0.0f, 0.0f, 1.0f,		1.0f, 0.2f,
		right, bottom, front,	0.0f, 0.0f, 1.0f,		1.0f, 0.0f,

		//Back Face				//Negative Z Normal
		left, bottom, back,		0.0f, 0.0f, -1.0f,		0.0f, 0.0f,
		right, bottom, back,	0.0f, 0.0f, -1.0f,		1.0f, 0.0f,
		left, top, back,		0.0f, 0.0f, -1.0f,		0.0f, 0.2f,

		left, top, back,		0.0f, 0.0f, -1.0f,		0.0f, 0.2f,
		right, top, back,		0.0f, 0.0f, -1.0f,		1.0f, 0.2f,
		right, bottom, back,	0.0f, 0.0f, -1.0f,		1.0f, 0.0f,

		//Right Face			//Positive X Normal
		right, bottom, front,	1.0f, 0.0f, 0.0f,		0.0f, 0.0f,
		right, bottom, back,	1.0f, 0.0f, 0.0f,		0.4f, 0.0f,
		right, top, front,		1.0f, 0.0f, 0.0f,		0.0f, 0.2f,

		right, bottom, back,	1.0f, 0.0f, 0.0f,		0.4f, 0.0f,
		right, top, back,		1.0f, 0.0f, 0.0f,		0.4f, 0.2f,
		right, top, front,		1.0f, 0.0f, 0.0f,		0.0f, 0.2f,

		//Left Face				//Negative X Normal
		left, bottom, front,	-1.0f, 0.0f, 0.0f,		0.0f, 0.0f,
		left, bottom, back,		-1.0f, 0.0f, 0.0f,		0.4f, 0.0f,
		left, top, front,		-1.0f, 0.0f, 0.0f,		0.0f, 0.2f,

		left, bottom, back,		-1.0f, 0.0f, 0.0f,		0.4f, 0.0f,
		left, top, back,		-1.0f, 0.0f, 0.0f,		0.4f, 0.2f,
		left, top, front,		-1.0f, 0.0f, 0.0f,		0.0f, 0.2f,

		//Top Face				//Positive Y Normal
		left, top, front,		0.0f, 1.0f, 0.0f,		0.0f, 0.0f,
		right, top, front,		0.0f, 1.0f, 0.0f,		1.0f, 0.0f,
		left, top, back,		0.0f, 1.0f, 0.0f,		0.0f, 1.0f,

		left, top, back,		0.0f, 1.0f, 0.0f,		0.0f, 1.0f,
		right, top, back,		0.0f, 1.0f, 0.0f,		1.0f, 1.0f,
		right, top, front,		0.0f, 1.0f, 0.0f,		1.0f, 0.0f,

		//Bottom Face			//Negative Y Normal
		left, bottom, front,	0.0f, -1.0f, 0.0f,		0.0f, 0.0f,
		right, bottom, front,	0.0f, -1.0f, 0.0f,		1.0f, 0.0f,
		left, bottom, back,		0.0f, -1.0f, 0.0f,		0.0f, 1.0f,

		left, bottom, back,		0.0f, -1.0f, 0.0f,		0.0f, 1.0f,
		right, bottom, back,	0.0f, -1.0f, 0.0f,		1.0f, 1.0f,
		right, bottom, front,	0.0f, -1.0f, 0.0f,		1.0f, 0.0f,
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

// Create the vertex and indicies for Shape Sorter Triangle mesh
void CreateShapeSorterTriangleMesh(GLMesh& mesh)
{
	// Position and Color data
	GLfloat verts[] = {
		// Vertex Positions		//Normals				// Texture Coordinates
		// ******************************************************************************
		//Front Face			//Negative Z Normal		
		-1.5f, 1.0f, 2.5f,		0.0f, 0.0f, -1.0f,		0.0f, 0.0f,
		0.5f, 1.0f, 2.5f,		0.0f, 0.0f, -1.0f,		1.0f, 0.0f,
		-1.5f, 3.0f, 2.5f,		0.0f, 0.0f, -1.0f,		0.0f, 1.0f,

		-1.5f, 3.0f, 2.5f,		0.0f, 0.0f, -1.0f,		0.0f, 1.0f,
		0.5f, 3.0f, 2.5f,		0.0f, 0.0f, -1.0f,		1.0f, 1.0f,
		0.5f, 1.0f, 2.5f,		0.0f, 0.0f, -1.0f,		1.0f, 0.0f,

		//Left Side				//Negative X Normals
		-1.5f, 1.0f, 2.5f,		-1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
		-1.5f, 3.0f, 2.5f,		-1.0f, 0.0f, 0.0f,		1.0f, 1.0f,
		-0.5f, 1.0f, 0.5f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.0f,

		-0.5f, 1.0f, 0.5f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.0f,
		-0.5f, 3.0f, 0.5f,		-1.0f, 0.0f, 0.0f,		0.0f, 1.0f,
		-1.5f, 3.0f, 2.5f,		-1.0f, 0.0f, 0.0f,		1.0f, 1.0f,

		//Right Side			//Positive X Normals
		0.5f, 1.0f, 2.5f,		1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
		0.5f, 3.0f, 2.5f,		1.0f, 0.0f, 0.0f,		1.0f, 1.0f,
		-0.5f, 1.0f, 0.5f,		1.0f, 0.0f, 0.0f,		0.0f, 0.0f,

		-0.5f, 1.0f, 0.5f,		1.0f, 0.0f, 0.0f,		0.0f, 0.0f,
		-0.5f, 3.0f, 0.5f,		1.0f, 0.0f, 0.0f,		0.0f, 1.0f,
		0.5f, 3.0f, 2.5f,		1.0f, 0.0f, 0.0f,		1.0f, 1.0f,

		//Top					//Positive Y Normals
		-1.5f, 3.0f, 2.5f,		0.0f, 1.0f, 0.0f,		0.0f, 0.0f,
		0.5f, 3.0f, 2.5f,		0.0f, 1.0f, 0.0f,		1.0f, 0.0f,
		-0.5f, 3.0f, 0.5f,		0.0f, 1.0f, 0.0f,		0.5f, 1.0f,

		//Top					//Negative Y Normals
		-1.5f, 1.0f, 2.5f,		0.0f, -1.0f, 0.0f,		0.0f, 0.0f,
		0.5f, 1.0f, 2.5f,		0.0f, -1.0f, 0.0f,		1.0f, 0.0f,
		-0.5f, 1.0f, 0.5f,		0.0f, -1.0f, 0.0f,		0.5f, 1.0f,



		// Add verts for stacker base
		// Vertex Positions    // Colors (r,g,b,a)
		/*-1.5f, 1.0f, 2.5f,      1.0f, 0.0f, 0.0f, 1.0f,
		 0.5f, 1.0f, 2.5f,      0.0f, 1.0f, 0.0f, 1.0f,
		-1.5f, 3.0f, 2.5f,      0.0f, 0.0f, 1.0f, 1.0f,
		 0.5f, 3.0f, 2.5f,      1.0f, 1.0f, 0.0f, 1.0f,

		-0.5f, 1.0f, 0.5f,      1.0f, 0.0f, 1.0f, 1.0f,
		-0.5f, 3.0f, 0.5f,      0.0f, 1.0f, 1.0f, 1.0f,*/
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

// Create the vertex and indicies for Shape Sorter Pentagon mesh
void CreateShapeSorterPentagonMesh(GLMesh& mesh)
{
	// Position and Color data

	// Base and top of cylinder
	GLfloat x = 4.5f;
	GLfloat z = 1.5f;
	GLfloat radius = 1.35f;
	GLint numberOfSides = 5;

	// numberOfVertices = numberOfSides + 2
	int numberOfVertices = numberOfSides + 2;

	GLfloat twicePi = 2.0f * PI;

	// Circle verts = numberOfVerticies * 8 data points
	// Total verts = base circle + top circle

	// Set arrays to numberOfVertices
	GLfloat circleVerticesX_Bottom[7];
	GLfloat circleVerticesZ_Bottom[7];
	GLfloat circleVerticesX_Top[7];
	GLfloat circleVerticesZ_Top[7];

	//Bottom Circle = numberOfSides * 3 points * 8 data values
	//Top Circle = numberOfSides * 3 points * 8 data values
	GLfloat verts[480];

	// Calculate the verticies for bottom
	// First vert is center of circle
	circleVerticesX_Bottom[0] = x;
	circleVerticesZ_Bottom[0] = z;
	for (int i = 1; i < numberOfVertices; i++)
	{
		circleVerticesX_Bottom[i] = x + (1.35f * cos(i * twicePi / numberOfSides));
		circleVerticesZ_Bottom[i] = z + (1.35f * sin(i * twicePi / numberOfSides));
	}

	// Bottom Circle
	for (int i = 0; i < numberOfSides; i++)
	{
		// Center Point
		verts[0 + (i * 24) + 0] = circleVerticesX_Bottom[0];
		verts[0 + (i * 24) + 1] = 1.0f;
		verts[0 + (i * 24) + 2] = circleVerticesZ_Bottom[0];

		// Negative Y Normals
		verts[0 + (i * 24) + 3] = 0.0f;
		verts[0 + (i * 24) + 4] = -1.0f;
		verts[0 + (i * 24) + 5] = 0.0f;

		// Texture
		verts[0 + (i * 24) + 6] = 0.0f;
		verts[0 + (i * 24) + 7] = 1.0f;


		// Point 1
		verts[0 + (i * 24) + 8] = circleVerticesX_Bottom[i + 1];
		verts[0 + (i * 24) + 9] = 1.0f;
		verts[0 + (i * 24) + 10] = circleVerticesZ_Bottom[i + 1];

		// Negative Y Normals
		verts[0 + (i * 24) + 11] = 0.0f;
		verts[0 + (i * 24) + 12] = -1.0f;
		verts[0 + (i * 24) + 13] = 0.0f;

		// Texture
		verts[0 + (i * 24) + 14] = 0.0f;
		verts[0 + (i * 24) + 15] = 1.0f;


		// Point 2
		verts[0 + (i * 24) + 16] = circleVerticesX_Bottom[i + 2];
		verts[0 + (i * 24) + 17] = 1.0f;
		verts[0 + (i * 24) + 18] = circleVerticesZ_Bottom[i + 2];

		// Negative Y Normals
		verts[0 + (i * 24) + 19] = 0.0f;
		verts[0 + (i * 24) + 20] = -1.0f;
		verts[0 + (i * 24) + 21] = 0.0f;

		// Texture
		verts[0 + (i * 24) + 22] = 0.0f;
		verts[0 + (i * 24) + 23] = 1.0f;
	}

	// Calculate the verticies for top - Allows for radius size change
	// First vert is center of circle
	circleVerticesX_Top[0] = x;
	circleVerticesZ_Top[0] = z;
	for (int i = 1; i < numberOfVertices; i++)
	{
		circleVerticesX_Top[i] = x + (1.35f * cos(i * twicePi / numberOfSides));
		circleVerticesZ_Top[i] = z + (1.35f * sin(i * twicePi / numberOfSides));
	}

	// Top Circle
	int startingVert = (numberOfSides * 3 * 8);
	for (int i = 0; i < numberOfSides; i++)
	{
		// Center Point
		verts[startingVert + (i * 24) + 0] = circleVerticesX_Top[0];
		verts[startingVert + (i * 24) + 1] = 3.0f;
		verts[startingVert + (i * 24) + 2] = circleVerticesZ_Top[0];

		// Positive Y Normals
		verts[startingVert + (i * 24) + 3] = 0.0f;
		verts[startingVert + (i * 24) + 4] = 1.0f;
		verts[startingVert + (i * 24) + 5] = 0.0f;

		// Texture
		verts[startingVert + (i * 24) + 6] = 0.0f;
		verts[startingVert + (i * 24) + 7] = 1.0f;


		// Point 1
		verts[startingVert + (i * 24) + 8] = circleVerticesX_Top[i + 1];
		verts[startingVert + (i * 24) + 9] = 3.0f;
		verts[startingVert + (i * 24) + 10] = circleVerticesZ_Top[i + 1];

		// Positive Y Normals
		verts[startingVert + (i * 24) + 11] = 0.0f;
		verts[startingVert + (i * 24) + 12] = 1.0f;
		verts[startingVert + (i * 24) + 13] = 0.0f;

		// Texture
		verts[startingVert + (i * 24) + 14] = 0.0f;
		verts[startingVert + (i * 24) + 15] = 1.0f;


		// Point 2
		verts[startingVert + (i * 24) + 16] = circleVerticesX_Top[i + 2];
		verts[startingVert + (i * 24) + 17] = 3.0f;
		verts[startingVert + (i * 24) + 18] = circleVerticesZ_Top[i + 2];

		// Positive Y Normals
		verts[startingVert + (i * 24) + 19] = 0.0f;
		verts[startingVert + (i * 24) + 20] = 1.0f;
		verts[startingVert + (i * 24) + 21] = 0.0f;

		// Texture
		verts[startingVert + (i * 24) + 22] = 0.0f;
		verts[startingVert + (i * 24) + 23] = 1.0f;
	}

	// Sides
	startingVert = (numberOfSides * 3 * 8) * 2;
	for (int i = 0; i < (numberOfSides); i++)
	{
#pragma region Triangle 1
		// Bottom Point 1
		verts[startingVert + (i * 48) + 0] = circleVerticesX_Bottom[i + 1];
		verts[startingVert + (i * 48) + 1] = 1.0f;
		verts[startingVert + (i * 48) + 2] = circleVerticesZ_Bottom[i + 1];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 3] = 0.0f;
		verts[startingVert + (i * 48) + 4] = 0.0f;
		verts[startingVert + (i * 48) + 5] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 6] = 0.0f;
		verts[startingVert + (i * 48) + 7] = 1.0f;


		// Bottom Point 2
		verts[startingVert + (i * 48) + 8] = circleVerticesX_Bottom[i + 2];
		verts[startingVert + (i * 48) + 9] = 1.0f;
		verts[startingVert + (i * 48) + 10] = circleVerticesZ_Bottom[i + 2];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 11] = 0.0f;
		verts[startingVert + (i * 48) + 12] = 0.0f;
		verts[startingVert + (i * 48) + 13] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 14] = 0.0f;
		verts[startingVert + (i * 48) + 15] = 1.0f;


		// Top Point 1
		verts[startingVert + (i * 48) + 16] = circleVerticesX_Top[i + 1];
		verts[startingVert + (i * 48) + 17] = 3.0f;
		verts[startingVert + (i * 48) + 18] = circleVerticesZ_Top[i + 1];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 19] = 0.0f;
		verts[startingVert + (i * 48) + 20] = 0.0f;
		verts[startingVert + (i * 48) + 21] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 22] = 0.0f;
		verts[startingVert + (i * 48) + 23] = 1.0f;
#pragma endregion


#pragma region Triangle 2
		// Top Point 1
		verts[startingVert + (i * 48) + 24] = circleVerticesX_Top[i + 1];
		verts[startingVert + (i * 48) + 25] = 3.0f;
		verts[startingVert + (i * 48) + 26] = circleVerticesZ_Top[i + 1];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 27] = 0.0f;
		verts[startingVert + (i * 48) + 28] = 0.0f;
		verts[startingVert + (i * 48) + 29] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 30] = 0.0f;
		verts[startingVert + (i * 48) + 31] = 1.0f;


		// Top Point 2
		verts[startingVert + (i * 48) + 32] = circleVerticesX_Top[i + 2];
		verts[startingVert + (i * 48) + 33] = 3.0f;
		verts[startingVert + (i * 48) + 34] = circleVerticesZ_Top[i + 2];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 35] = 0.0f;
		verts[startingVert + (i * 48) + 36] = 0.0f;
		verts[startingVert + (i * 48) + 37] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 38] = 0.0f;
		verts[startingVert + (i * 48) + 39] = 1.0f;


		// Bottom Point 2
		verts[startingVert + (i * 48) + 40] = circleVerticesX_Bottom[i + 2];
		verts[startingVert + (i * 48) + 41] = 1.0f;
		verts[startingVert + (i * 48) + 42] = circleVerticesZ_Bottom[i + 2];

		// Positive Z Normals
		verts[startingVert + (i * 48) + 43] = 0.0f;
		verts[startingVert + (i * 48) + 44] = 0.0f;
		verts[startingVert + (i * 48) + 45] = 1.0f;

		// Texture
		verts[startingVert + (i * 48) + 46] = 0.0f;
		verts[startingVert + (i * 48) + 47] = 1.0f;
#pragma endregion
	}


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerTexture = 2;

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

// Destroys the mesh passed
void DestroyMesh(GLMesh& mesh)
{
	glDeleteVertexArrays(1, &mesh.vao);
	glDeleteBuffers(2, mesh.vbos);
}

// Load all the textures
void LoadAllTextures()
{
	// Load textures

	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	glUseProgram(gProgramId);

	// Floor
	const char* texFilename = "textures/wood.jpg";
	if (!CreateTexture(texFilename, gFloorTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Storage Cube
	texFilename = "textures/fabric.jpg";
	if (!CreateTexture(texFilename, gStorageCubeTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	texFilename = "textures/lion.jpg";
	if (!CreateTexture(texFilename, gStorageCubeExtraTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);
	// We set the texture as texture unit 1
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureExtra"), 1);

	// Beige
	texFilename = "textures/sorterBase.jpg";
	if (!CreateTexture(texFilename, gSorterBaseTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Pink
	texFilename = "textures/pink.jpg";
	if (!CreateTexture(texFilename, gPinkTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Yellow
	texFilename = "textures/yellow.jpg";
	if (!CreateTexture(texFilename, gYellowTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Green
	texFilename = "textures/green.jpg";
	if (!CreateTexture(texFilename, gGreenTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Blue
	texFilename = "textures/blue.jpg";
	if (!CreateTexture(texFilename, gBlueTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Orange
	texFilename = "textures/orange.jpg";
	if (!CreateTexture(texFilename, gOrangeTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// White
	texFilename = "textures/white.jpg";
	if (!CreateTexture(texFilename, gWhiteTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Light Gray
	texFilename = "textures/lightGray.jpg";
	if (!CreateTexture(texFilename, gLightGrayTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Gray
	texFilename = "textures/gray.jpg";
	if (!CreateTexture(texFilename, gGrayTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Black
	texFilename = "textures/black.jpg";
	if (!CreateTexture(texFilename, gBlackTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);

	// Off White
	texFilename = "textures/offWhite.jpg";
	if (!CreateTexture(texFilename, gOffWhiteTexture))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return;
	}
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);
}

/*Generate and load the texture*/
bool CreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

// Release textures
void DestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}

// Functioned called to render a frame
void Render(Shader lightingShader, Shader lightCubeShader)
{
	// Set change of time for camera movement
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// ADDED - Set lighting values
	// be sure to activate shader when setting uniforms/drawing objects
	lightingShader.use();
	lightingShader.setVec3("viewPos", gCamera.Position);
	lightingShader.setFloat("material.shininess", 32.0f);

#pragma region Lights
	// Key Light - directional light
	// Set lights direction
	lightingShader.setVec3("dirLight.direction", 1.0f, -1.0f, -1.0f);
	// Set color of ambient light
	lightingShader.setVec3("dirLight.ambient", 0.2f, 0.2f, 0.2f);
	// Set color of diffuse light
	lightingShader.setVec3("dirLight.diffuse", 0.8f, 0.8f, 0.8f);
	// Set color of specular light
	lightingShader.setVec3("dirLight.specular", 0.1f, 0.1f, 0.1f);
	// Set intensity light to 100%
	lightingShader.setFloat("dirLight.intensity", 0.3f);

	// Fill Light - point light 1
	lightingShader.setVec3("pointLights[0].position", pointLightPositions[0]);
	// Set color of ambient light
	lightingShader.setVec3("pointLights[0].ambient", 0.2f, 0.2f, 0.2f);
	// Set color of diffuse light
	lightingShader.setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.4f);
	// Set color of specular light
	lightingShader.setVec3("pointLights[0].specular", 0.1f, 0.1f, 0.1f);
	lightingShader.setFloat("pointLights[0].constant", 1.0f);
	lightingShader.setFloat("pointLights[0].linear", 0.09);
	lightingShader.setFloat("pointLights[0].quadratic", 0.032);
	// Set intensity light to 100%
	lightingShader.setFloat("pointLights[0].intensity", 1.0f);

	// Fill Light - point light 2
	lightingShader.setVec3("pointLights[1].position", pointLightPositions[1]);
	// Set color of ambient light
	lightingShader.setVec3("pointLights[1].ambient", 0.2f, 0.2f, 0.2f);
	// Set color of diffuse light
	lightingShader.setVec3("pointLights[1].diffuse", 0.8f, 0.8f, 0.4f);
	// Set color of specular light
	lightingShader.setVec3("pointLights[1].specular", 0.1f, 0.1f, 0.1f);
	lightingShader.setFloat("pointLights[1].constant", 1.0f);
	lightingShader.setFloat("pointLights[1].linear", 0.09);
	lightingShader.setFloat("pointLights[1].quadratic", 0.032);
	// Set intensity light to 100%
	lightingShader.setFloat("pointLights[1].intensity", 1.0f);
#pragma endregion

	// world transformation
	glm::mat4 model = glm::mat4(1.0f);
	lightingShader.setMat4("model", model);

#pragma region Camera
	// view/projection transformations
	glm::mat4 projection;
	if (gCameraView == PERSPECTIVE)
		// Creates a perspective projection
		projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	else if (gCameraView == ORTHOGRAPHIC)
		// Creates a orthographic projection
		projection = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, 0.1f, 1000.0f);

	glm::mat4 view = gCamera.GetViewMatrix();
	lightingShader.setMat4("projection", projection);
	lightingShader.setMat4("view", view);
#pragma endregion
	
#pragma region Floor
	// Rotate
	rotation = glm::rotate(-0.1f, glm::vec3(0.0f, 1.0f, 0.0f));
	// Move floor
	translation = glm::translate(glm::vec3(10.0f, 0.0f, -12.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader program to not use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gFloorMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gFloorTexture);

	// Draws the triangles
	glDrawElements(GL_TRIANGLES, gFloorMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangles
#pragma endregion
	
#pragma region Wall
	// Rotate
	//rotation = glm::rotate(-0.1f, glm::vec3(0.0f, 1.0f, 0.0f));
	// Move floor
	//translation = glm::translate(glm::vec3(10.0f, 0.0f, -12.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader program to not use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gWallMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gOffWhiteTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

#pragma region Baseboard
	// Move storage cube
	//translation = glm::translate(glm::vec3(1.0f, 0.0f, -12.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);
	//glUniform1i(multipleTexturesLoc, true);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gBaseboardMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gWhiteTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

#pragma region Storage Cube
	// Move storage cube
	translation = glm::translate(glm::vec3(1.0f, 0.0f, -12.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", true);
	//glUniform1i(multipleTexturesLoc, true);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStorageCubeMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gStorageCubeTexture);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, gStorageCubeExtraTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

#pragma region Shaker 1 Mesh
	// Move object
	translation = glm::translate(glm::vec3(11.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

#pragma region Bottom Mesh
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShaker1BottomMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gBlackTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Top Mesh
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShaker1TopMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gGrayTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma endregion

#pragma region Shaker 2 Mesh
	// Move object
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(9.0f, 0.0f, -11.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

#pragma region Bottom Mesh
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShaker2BottomMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gLightGrayTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Top Mesh
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShaker2TopMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gGrayTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion
#pragma endregion

#pragma region Shape Sorter Base
	// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move object
	translation = glm::translate(glm::vec3(5.0f, 0.0f, -5.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader not to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShapeSorterBaseMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gSorterBaseTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

#pragma region Shape Sorter Circle Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(5.0f, 0.0f, -5.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShapeSorterCircleMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gPinkTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Shape Sorter Rectangle Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(5.0f, 0.0f, -5.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShapeSorterRectangleMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gYellowTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

#pragma region Shape Sorter Triangle Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(5.0f, 0.0f, -5.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShapeSorterTriangleMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gGreenTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 24);
#pragma endregion

#pragma region Shape Sorter Square Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(5.0f, 0.0f, -5.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShapeSorterSquareMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gBlueTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

#pragma region Shape Sorter Pentagon Mesh
// Rotate
	rotation = glm::rotate(0.17f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(4.1f, 0.0f, -3.8f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gShapeSorterPentagonMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gOrangeTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 60);
#pragma endregion

#pragma region Stacker Base Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerBaseMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gWhiteTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 72);
#pragma endregion

#pragma region Stacker Center Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerCenterMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gYellowTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Stacker Ring 1 Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerRing1Mesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gBlueTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Stacker Ring 2 Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerRing2Mesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gGreenTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Stacker Ring 3 Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerRing3Mesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gYellowTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Stacker Ring 4 Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerRing4Mesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gOrangeTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Stacker Ring 5 Mesh
// Rotate
	rotation = glm::rotate(0.5f, glm::vec3(0.0f, -1.0f, 0.0f));
	// Move shape sorter to center
	translation = glm::translate(glm::vec3(14.0f, 0.0f, -10.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gStackerRing5Mesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gPinkTexture);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, 192);
#pragma endregion

#pragma region Ball Mesh
	// Scale ball
	glm::mat4 ballScale = glm::scale(glm::vec3(3.5f, 3.5f, 3.5f));
	// Move ball
	translation = glm::translate(glm::vec3(-5.0f, 3.5f, -8.0f));
	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * ballScale;

	lightingShader.setMat4("model", model);

	// Tell shader to use multiple textures
	lightingShader.setBool("material.multipleTextures", false);

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gBallMesh.vao);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gWhiteTexture);

	// Draws the triangles
	glDrawElements(GL_TRIANGLES, gBallMesh.nIndices, GL_UNSIGNED_SHORT, (void*)gBallMesh.sphereIndexByteOffset);
#pragma endregion

#pragma region Lights
	// Draw the lamp object(s)
	lightCubeShader.use();
	lightCubeShader.setMat4("projection", projection);
	lightCubeShader.setMat4("view", view);

	// we now draw as many light bulbs as we have point lights.
	glBindVertexArray(gLightCubeMesh.vao);
	for (unsigned int i = 0; i < sizeof(pointLightPositions) / sizeof(glm::vec3); i++)
	{
		model = glm::mat4(1.0f);
		model = glm::translate(model, pointLightPositions[i]);
		model = glm::scale(model, glm::vec3(0.2f)); // Make it a smaller cube
		lightCubeShader.setMat4("model", model);
		// Draw the lights - not needed visually
		//glDrawArrays(GL_TRIANGLES, 0, 36);
	}
#pragma endregion
}